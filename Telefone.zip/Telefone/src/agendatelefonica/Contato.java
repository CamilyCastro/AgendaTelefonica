package agendatelefonica;

public class Contato 
{
    protected String nome;
    private String sobrenome;
    private Telefone telefone;
  
    
     public Contato(String nome, String sobrenome, String numFone)
    {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.telefone = new Telefone(numFone);
    };
    
    public Contato(String nome, String sobrenome, String numDDD, String numFone)
    {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.telefone = new Telefone(numDDD, numFone);
             
    };
    
    
    public Contato(String nome, String sobrenome, String inter, String numDDD, String numFone)
    {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.telefone = new Telefone(inter, numDDD, numFone);
        
    };
    
    public Contato(String nome, String sobrenome)
    {
        this.nome = nome;
        this.sobrenome = sobrenome;       
    };
    
    @Override
    public String toString() {
        return "Contato{" + "" + nome + " " + sobrenome + ", " + telefone + '}';
    }
}
