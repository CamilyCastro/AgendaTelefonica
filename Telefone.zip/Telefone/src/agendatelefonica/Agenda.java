package agendatelefonica;

import java.util.ArrayList;

public class Agenda 
{
   ArrayList<Contato> contatos;
   
   public Agenda(ArrayList<Contato> contatos)
   {
       this.contatos = contatos;
   }
   
   public void inserirContato(Contato contatos)
   {
       if(this.contatos.size() <= 5){
           this.contatos.add(contatos);
       }else{
           System.out.println("Limite de cinco contatos atingido.");
       }   
   }
   
   public void excluirContato(String nome)
   {
       Contato excluir = null;
       
       for(Contato contato : this.contatos)
       {
           if(contato.nome.equals(nome)){
               excluir = contato;
           }
       }
       
       if(excluir == null){
           System.out.println("Não encontrado.");
       }else{
           this.contatos.remove(excluir);
       }
   }
   
   public Contato buscar(String nome)
   {
       Contato buscar = null;
       
       for(Contato contato : this.contatos)
       {
           if(contato.nome.equals(nome)){
               buscar = contato;
           }
       }
       
       if(buscar == null){
           System.out.println("Não encontrado.");
       }
           return buscar;
       
   }
   
    public void imprimirContatos()
    {
        for(Contato contato : this.contatos)
        {
            System.out.println(contato.toString());
        }
    }
}
