package agendatelefonica;

public class Telefone
{
    private String codInter;
    private String DDD;
    private String numTel;
    
    public Telefone(String codInter, String DDD, String numTel){
        this.codInter = codInter;
        this.DDD = DDD;
        this.numTel = numTel;  
    };
    
    public Telefone(String DDD, String numTel){
        this.codInter = "+55";
        this.DDD = DDD;
        this.numTel = numTel;
    };
    
    public Telefone(String numTel){
        this.codInter = "+55";
        this.DDD = "16";
        this.numTel = numTel;
    };
    
    String telefone()
    {
        String telefone = this.codInter + this.DDD + this.numTel;
        
        return telefone;
    }
    
    @Override
    public String toString() {
        return "Telefone{" + "" + codInter + " " + DDD + " " + numTel + '}';
    }
}
