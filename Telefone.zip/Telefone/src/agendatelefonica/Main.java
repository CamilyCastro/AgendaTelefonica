package agendatelefonica;

import java.util.ArrayList;
import java.util.List;

public class Main 
{

    public static void main(String[] args) 
    {
        Telefone fone1 = new Telefone("+55", "16", "997315224");
        Telefone fone2 = new Telefone("16", "997624758");
        Telefone fone3 = new Telefone("997370532");
        Telefone fone4 = new Telefone("+55", "16", "997086160");
        Telefone fone5 = new Telefone("+55", "16", "997458216");
  
        Contato cont1 = new Contato("Camily", "Castro", fone1.telefone());
        Contato cont2 = new Contato("Milena", "Vieira", "16", "997624758");
        Contato cont3 = new Contato("Cleiton", "Castro");
        Contato cont4 = new Contato("Marta", "Vieira", "997086160");
        Contato cont5 = new Contato("Eduardo", "Leal", fone5.telefone());
      
        ArrayList<Contato> contatos = new ArrayList<>();
        
        Agenda agenda = new Agenda(contatos);
        agenda.inserirContato(cont1);
        agenda.inserirContato(cont2);
        agenda.inserirContato(cont3);
        agenda.inserirContato(cont4);
        agenda.inserirContato(cont5);
        
        agenda.buscar("Caio");
        
        agenda.excluirContato("Camily");
        
        agenda.imprimirContatos();
        
    }
    
}
